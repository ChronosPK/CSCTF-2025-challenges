from src.etl.ingest import clean_row
def test_clean_row(): assert clean_row({"a":" x "})["a"]=="x"
