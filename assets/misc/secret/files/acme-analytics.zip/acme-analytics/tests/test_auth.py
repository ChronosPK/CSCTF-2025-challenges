from src.api import auth
def test_mint_token(): assert isinstance(auth.mint("user"), str)
