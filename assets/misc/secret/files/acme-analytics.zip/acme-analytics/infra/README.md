# Infra
Future: Terraform for S3-like object store and Redis. For now: docker-compose only.
