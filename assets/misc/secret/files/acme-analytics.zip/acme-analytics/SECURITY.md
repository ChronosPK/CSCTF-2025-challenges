# Security Policy
Report issues to security@acme.local. Rotate data keys before minor releases.
