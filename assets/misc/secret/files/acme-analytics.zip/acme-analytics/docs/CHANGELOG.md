# Changelog
## v0.2.0
- Auth token minting
- Data events and SQL sample
- Policies and docs
