# API spec
- GET /healthz -> {"ok":true}
- GET /metrics/users -> {"count":N}
- GET /auth/mint?sub=<id> -> {"token": "..."}
