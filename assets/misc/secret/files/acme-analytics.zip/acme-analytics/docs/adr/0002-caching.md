# ADR-0002: Response caching
Choice: no cache now; plan for Redis at v0.3 to cache /metrics endpoints.
