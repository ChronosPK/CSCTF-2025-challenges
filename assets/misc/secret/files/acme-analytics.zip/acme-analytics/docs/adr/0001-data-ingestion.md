# ADR-0001: CSV ingestion
Decision: Python-based CSV ingestion (simplicity). Revisit if volume > 10M rows/day.
