# acme-analytics
Internal analytics stack: Python 3.11, FastAPI, Pandas. CI via GitHub Actions. Deps managed by pyproject.
