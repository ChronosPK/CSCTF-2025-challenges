# Contributing
Run pre-commit, add tests, keep commits atomic.
