import logging, os
def setup_logger():
    lvl = os.getenv("LOG_LEVEL","INFO").upper()
    logging.basicConfig(level=getattr(logging, lvl, logging.INFO))
    return logging.getLogger("acme")
