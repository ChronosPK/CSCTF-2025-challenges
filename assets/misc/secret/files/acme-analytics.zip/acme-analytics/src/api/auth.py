import time, jwt, os
SECRET = os.getenv("JWT_SECRET","devsecret")
def mint(sub: str, exp_s: int = 900) -> str:
    now = int(time.time())
    return jwt.encode({"sub": sub, "iat": now, "exp": now+exp_s}, SECRET, algorithm="HS256")
