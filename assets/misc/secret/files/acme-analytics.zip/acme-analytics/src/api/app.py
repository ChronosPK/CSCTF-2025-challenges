# Copyright (c) Acme
from fastapi import FastAPI
import os, pathlib
app = FastAPI()
@app.get("/healthz")
def healthz(): return {"ok": True}
@app.get("/metrics/users")
def users_metric():
    data_dir = pathlib.Path(os.getenv("DATA_DIR","data/processed"))
    f = data_dir / "customers_clean.csv"
    return {"count": (sum(1 for _ in f.open(encoding="utf-8")) - 1) if f.exists() else 0}

from fastapi import HTTPException
from . import auth as _auth

@app.get("/auth/mint")
def mint(sub: str = "demo"):
    try:
        return {"token": _auth.mint(sub)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
