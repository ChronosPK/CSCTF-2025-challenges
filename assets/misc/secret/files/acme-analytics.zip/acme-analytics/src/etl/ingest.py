import csv, pathlib
def clean_row(row: dict) -> dict:
    return {k: v.strip() if isinstance(v, str) else v for k,v in row.items()}
def ingest_csv(src: str, dst: str) -> int:
    src_p, dst_p = pathlib.Path(src), pathlib.Path(dst)
    dst_p.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with src_p.open(newline='', encoding='utf-8') as f_in, dst_p.open('w', newline='', encoding='utf-8') as f_out:
        reader = csv.DictReader(f_in); writer = csv.DictWriter(f_out, fieldnames=reader.fieldnames)
        writer.writeheader()
        for row in reader:
            writer.writerow(clean_row(row)); count += 1
    return count
