-- returns customers by org, descending count
SELECT org, COUNT(*) AS c FROM customers GROUP BY org ORDER BY c DESC;
