SecureVault Field Restore
Tags: AES-CBC, PKCS#7, padding oracle | Difficulty: Medium

Deliverables:
- svlt-verify/    (offline verifier; exit codes only)
- backup_target.svlt
- SHA256SUMS

Verifier exit codes:
  0=OK, 20=Integrity failure, 10=Padding error, 2=Bad format

Task:
Recover the plaintext of backup_target.svlt and submit secret=CSCTF{...}.

Notes:
- AES-256-CBC + PKCS#7; HMAC-SHA256; decrypt-then-verify (legacy).
- Treat the verifier as a black-box oracle. Operate on ciphertext, not the header.
