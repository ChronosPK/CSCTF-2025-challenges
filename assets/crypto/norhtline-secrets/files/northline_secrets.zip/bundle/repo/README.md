Northline production GitOps snapshot.
- Kustomize overlays in ./environments
- Secrets are SOPS-managed and committed as *.enc.yaml
- Decrypt in CI/CD; plaintext secrets must never be committed
